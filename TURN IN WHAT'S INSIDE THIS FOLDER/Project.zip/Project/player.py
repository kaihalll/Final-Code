# player.py

# Stores player infomration
player_health = 100
player_max_health = 100
player_attack_power = 20
heal_potions = 3
player_inventory = [] #Only for key items
souls = 5
current_room = 'Dungeon'